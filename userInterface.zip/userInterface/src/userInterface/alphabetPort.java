package userInterface;
import java.io.*;
import org.json.*;
//import Servlet package
import javax.servlet.*;
import javax.servlet.http.*;
public class alphabetPort extends HttpServlet{
	//input and output String
	private String alphabet;
	private String output;
	
	public void init() throws ServletException
	{
		output = "ERROR";
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//get alphabet
		alphabet = request.getParameter("alphabet");
		//respond with MQ and EQ
		//Add the logic here:(sketch) 
		//function(alphabet){output = outputText} 
		//The function to respond to the first call
		output = "{\"MQ\":\"MQ is good\",\"EQ\":\"EQ is good\"}";
		
		
		
		
		
		//response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	public void destroy()
	{
		
	}
	
}
