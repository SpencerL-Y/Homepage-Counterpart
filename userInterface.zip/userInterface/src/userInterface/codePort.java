package userInterface;
import java.io.*;
import org.json.*;
//import Servlet package
import javax.servlet.*;
import javax.servlet.http.*;
public class codePort extends HttpServlet{
	//input and output String
	private String code;
	private String output;
	
	public void init() throws ServletException
	{
		output = "ERROR";
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//get alphabet
		
		//respond with MQ and EQ
		
		code = request.getParameter("code");
		//function(code){return output} 
		//Modify your logic here:(sketch) 
		output = "{\"result\":\"" +code+ "\"}";
		
		
		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	public void destroy()
	{
		
	}
	
}