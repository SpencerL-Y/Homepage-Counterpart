package userInterface;
import java.io.*;
import org.json.*;
//import Servlet package
import javax.servlet.*;
import javax.servlet.http.*;
public class Button extends HttpServlet{
	//input and output String
	private String value;
	private String output;
	
	public void init() throws ServletException
	{
		output = "ERROR";
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//get alphabet
		value = request.getParameter("value");
		//respond with MQ and EQ
		
		String a = "MQY";
		String b = "MQN";
		String c = "EQY";
		String d = "EQN";
		if(value.equals(a))
		{
			//Add the logic here:(sketch) 
			//function(){} 
			output = "{\"MQ\":\"MQ is MQY \",\"EQ\":\"EQ is MQY\"}";
		}
		
		else if(value.equals(b))
		{
			//Add the logic here:(sketch) 
			//function(){} 
			output = "{\"MQ\":\"MQ is MQN \",\"EQ\":\"EQ is MQN\"}";
		}
		else if(value.equals(c))
		{
			//Add the logic here:(sketch) 
			//function(){} 
			output = "{\"MQ\":\"MQ is EQY \",\"EQ\":\"EQ is EQY\"}";
		}
		else if(value.equals(d))
		{
			//Add the logic here:(sketch) 
			//function(){} 
			output = "{\"MQ\":\"MQ is EQN \",\"EQ\":\"EQ is EQN\"}";
		}
		else 
		{
			output = "ERROR";
		}
		
		
		
		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	public void destroy()
	{
		
	}
	
}
